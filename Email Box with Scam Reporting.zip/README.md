
  # Email Box with Scam Reporting

  This is a code bundle for Email Box with Scam Reporting. The original project is available at https://www.figma.com/design/6IB5ozzG7qboFkkdruBi7I/Email-Box-with-Scam-Reporting.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  