import { EmailInbox } from './components/EmailInbox';

export default function App() {
  return (
    <div className="size-full bg-background">
      <EmailInbox />
    </div>
  );
}