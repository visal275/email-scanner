import { useState } from 'react';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { 
  Shield, 
  ShieldAlert, 
  CheckCircle, 
  AlertTriangle, 
  Scan,
  X,
  Flag
} from 'lucide-react';
import { Email, RiskLevel } from './EmailInbox';

interface EmailScannerProps {
  emails: Email[];
  onScanComplete: (scannedEmails: Email[]) => void;
  isOpen: boolean;
  onClose: () => void;
}

interface ScanResult {
  emailId: string;
  threats: string[];
  riskLevel: RiskLevel;
}

export function EmailScanner({ emails, onScanComplete, isOpen, onClose }: EmailScannerProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [progress, setProgress] = useState(0);
  const [scanResults, setScanResults] = useState<ScanResult[]>([]);
  const [currentScanIndex, setCurrentScanIndex] = useState(0);

  const scanEmail = (email: Email): ScanResult => {
    const threats: string[] = [];
    let riskLevel: RiskLevel = 'safe';

    // Check for confirmed scam indicators (highest priority)
    const scamDomains = ['secure-paypal.net', 'amazon-security.org', 'apple-billing.com', 'microsoft-support.net'];
    const scamLinks = ['http://secure-paypal.net', 'bit.ly/secure-login', 'tinyurl.com/account-verify'];
    const scamPatterns = ['verify your account within 24 hours', 'your account will be suspended', 'confirm your identity immediately'];
    
    const hasScamDomain = scamDomains.some(domain => email.senderEmail.includes(domain));
    const hasScamLinks = scamLinks.some(link => email.content.includes(link));
    const hasScamPatterns = scamPatterns.some(pattern => 
      email.content.toLowerCase().includes(pattern.toLowerCase())
    );

    if (hasScamDomain || hasScamLinks || hasScamPatterns) {
      riskLevel = 'scam';
      if (hasScamDomain) threats.push('Known phishing domain');
      if (hasScamLinks) threats.push('Suspicious shortened links');
      if (hasScamPatterns) threats.push('Account threat language');
    }
    // Check for high-risk indicators
    else {
      const urgentKeywords = ['urgent', 'immediately', 'suspended', 'expires', 'limited time'];
      const phishingKeywords = ['verify account', 'update payment', 'confirm identity', 'billing problem'];
      const hasUrgentKeywords = urgentKeywords.some(keyword => 
        email.subject.toLowerCase().includes(keyword) || 
        email.content.toLowerCase().includes(keyword)
      );
      const hasPhishingKeywords = phishingKeywords.some(keyword => 
        email.content.toLowerCase().includes(keyword)
      );

      if (hasUrgentKeywords && hasPhishingKeywords) {
        riskLevel = 'high-risk';
        threats.push('High-pressure tactics detected');
        threats.push('Requests sensitive information');
      }
      // Check for suspicious indicators
      else {
        const suspiciousPatterns = [
          { pattern: 'payp4l', description: 'Domain spoofing attempt' },
          { pattern: 'amaz0n', description: 'Brand impersonation' },
          { pattern: 'action required', description: 'Urgency manipulation' },
          { pattern: 'payment failed', description: 'False payment alert' },
          { pattern: 'security notice', description: 'Fake security warning' }
        ];

        const foundSuspicious = suspiciousPatterns.filter(({ pattern }) => 
          email.subject.toLowerCase().includes(pattern.toLowerCase()) ||
          email.content.toLowerCase().includes(pattern.toLowerCase()) ||
          email.senderEmail.toLowerCase().includes(pattern.toLowerCase())
        );

        if (foundSuspicious.length > 0) {
          riskLevel = 'suspicious';
          foundSuspicious.forEach(({ description }) => threats.push(description));
        }

        // Check for generic urgency without specific scam patterns
        if (riskLevel === 'safe' && hasUrgentKeywords) {
          riskLevel = 'suspicious';
          threats.push('Uses pressure tactics');
        }
      }
    }

    return {
      emailId: email.id,
      threats,
      riskLevel
    };
  };

  const startScan = async () => {
    setIsScanning(true);
    setProgress(0);
    setScanResults([]);
    setCurrentScanIndex(0);

    const results: ScanResult[] = [];

    for (let i = 0; i < emails.length; i++) {
      setCurrentScanIndex(i);
      setProgress((i / emails.length) * 100);
      
      // Simulate scanning delay
      await new Promise(resolve => setTimeout(resolve, 300));
      
      const result = scanEmail(emails[i]);
      results.push(result);
    }

    setProgress(100);
    setScanResults(results);
    setIsScanning(false);

    // Update emails with scan results
    const updatedEmails = emails.map(email => {
      const result = results.find(r => r.emailId === email.id);
      if (result && result.riskLevel !== 'safe') {
        return {
          ...email,
          isFlagged: true,
          isScam: result.riskLevel === 'scam',
          riskLevel: result.riskLevel
        };
      }
      return { ...email, riskLevel: 'safe' };
    });

    onScanComplete(updatedEmails);
  };

  const threatCount = scanResults.filter(r => r.riskLevel !== 'safe').length;
  const scamCount = scanResults.filter(r => r.riskLevel === 'scam').length;
  const highRiskCount = scanResults.filter(r => r.riskLevel === 'high-risk').length;
  const suspiciousCount = scanResults.filter(r => r.riskLevel === 'suspicious').length;

  const getRiskBadge = (riskLevel: RiskLevel) => {
    switch (riskLevel) {
      case 'scam':
        return <Badge variant="destructive">Scam Warning</Badge>;
      case 'high-risk':
        return <Badge className="bg-orange-100 text-orange-800">High Risk</Badge>;
      case 'suspicious':
        return <Badge className="bg-yellow-100 text-yellow-800">Suspicious</Badge>;
      default:
        return <Badge variant="secondary">Safe</Badge>;
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <Card className="w-full max-w-2xl m-4 max-h-[80vh] overflow-hidden">
        <div className="p-6 border-b flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            <h2>Email Security Scanner</h2>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </div>

        <div className="p-6 space-y-6">
          {!isScanning && scanResults.length === 0 && (
            <div className="text-center space-y-4">
              <div className="flex justify-center">
                <div className="p-4 bg-blue-50 rounded-full">
                  <Scan className="h-8 w-8 text-blue-600" />
                </div>
              </div>
              <div>
                <h3>Scan Your Emails for Threats</h3>
                <p className="text-muted-foreground">
                  Our scanner will analyze {emails.length} emails for phishing attempts, scams, and suspicious content.
                </p>
              </div>
              <Button onClick={startScan} className="w-full">
                <Scan className="h-4 w-4 mr-2" />
                Start Security Scan
              </Button>
            </div>
          )}

          {isScanning && (
            <div className="space-y-4">
              <div className="text-center">
                <h3>Scanning Emails...</h3>
                <p className="text-muted-foreground">
                  Analyzing email {currentScanIndex + 1} of {emails.length}
                </p>
              </div>
              <Progress value={progress} className="w-full" />
              <div className="text-center text-sm text-muted-foreground">
                {Math.round(progress)}% Complete
              </div>
            </div>
          )}

          {!isScanning && scanResults.length > 0 && (
            <div className="space-y-4">
              <div className="grid grid-cols-4 gap-4 text-center">
                <div className="space-y-2">
                  <div className="flex justify-center">
                    <CheckCircle className="h-6 w-6 text-green-500" />
                  </div>
                  <div>
                    <div className="font-medium">{emails.length - threatCount}</div>
                    <div className="text-sm text-muted-foreground">Safe</div>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-center">
                    <Flag className="h-6 w-6 text-yellow-500" />
                  </div>
                  <div>
                    <div className="font-medium">{suspiciousCount}</div>
                    <div className="text-sm text-muted-foreground">Suspicious</div>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-center">
                    <ShieldAlert className="h-6 w-6 text-orange-500" />
                  </div>
                  <div>
                    <div className="font-medium">{highRiskCount}</div>
                    <div className="text-sm text-muted-foreground">High Risk</div>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-center">
                    <AlertTriangle className="h-6 w-6 text-red-500" />
                  </div>
                  <div>
                    <div className="font-medium">{scamCount}</div>
                    <div className="text-sm text-muted-foreground">Scam Warnings</div>
                  </div>
                </div>
              </div>

              {threatCount > 0 && (
                <div className="space-y-2">
                  <h4>Detected Threats</h4>
                  <div className="max-h-60 overflow-y-auto space-y-2">
                    {scanResults
                      .filter(r => r.riskLevel !== 'safe')
                      .map(result => {
                        const email = emails.find(e => e.id === result.emailId);
                        return (
                          <div key={result.emailId} className="p-3 border rounded-lg space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="font-medium truncate flex-1 mr-2">
                                {email?.subject}
                              </div>
                              {getRiskBadge(result.riskLevel)}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              From: {email?.senderEmail}
                            </div>
                            <div className="flex flex-wrap gap-1">
                              {result.threats.map((threat, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {threat}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>
              )}

              <div className="flex gap-2 pt-4">
                <Button onClick={() => {
                  setScanResults([]);
                  setProgress(0);
                }} variant="outline" className="flex-1">
                  Scan Again
                </Button>
                <Button onClick={onClose} className="flex-1">
                  Close
                </Button>
              </div>
            </div>
          )}
        </div>
      </Card>
    </div>
  );
}