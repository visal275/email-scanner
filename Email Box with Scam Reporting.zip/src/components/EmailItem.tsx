import { Email, RiskLevel } from './EmailInbox';
import { Badge } from './ui/badge';
import { Card } from './ui/card';
import { Flag, AlertTriangle, Shield } from 'lucide-react';

interface EmailItemProps {
  email: Email;
  isSelected: boolean;
  onSelect: () => void;
}

const getRiskBadge = (riskLevel?: RiskLevel) => {
  switch (riskLevel) {
    case 'scam':
      return (
        <Badge variant="destructive" className="text-xs">
          <AlertTriangle className="h-3 w-3 mr-1" />
          Scam Warning
        </Badge>
      );
    case 'high-risk':
      return (
        <Badge className="text-xs bg-orange-100 text-orange-800 hover:bg-orange-200">
          <Shield className="h-3 w-3 mr-1" />
          High Risk
        </Badge>
      );
    case 'suspicious':
      return (
        <Badge className="text-xs bg-yellow-100 text-yellow-800 hover:bg-yellow-200">
          <Flag className="h-3 w-3 mr-1" />
          Suspicious
        </Badge>
      );
    default:
      return null;
  }
};

const getFlagColor = (riskLevel?: RiskLevel) => {
  switch (riskLevel) {
    case 'scam':
      return 'text-red-500';
    case 'high-risk':
      return 'text-orange-500';
    case 'suspicious':
      return 'text-yellow-500';
    default:
      return 'text-orange-500';
  }
};

const highlightPreviewText = (text: string, riskLevel?: RiskLevel): string => {
  if (!riskLevel || riskLevel === 'safe') return text;

  const urgentKeywords = ['urgent', 'immediately', 'verify', 'suspended', 'expires', 'limited time'];
  let highlightedText = text;

  urgentKeywords.forEach(keyword => {
    const regex = new RegExp(`(${keyword})`, 'gi');
    highlightedText = highlightedText.replace(regex, '<span class="bg-orange-100 text-orange-800 px-0.5 rounded text-xs">$1</span>');
  });

  return highlightedText;
};

const highlightSenderEmail = (email: string, riskLevel?: RiskLevel): JSX.Element => {
  if (!riskLevel || riskLevel === 'safe') return <span>{email}</span>;

  const suspiciousDomains = [
    'secure-paypal.net',
    'amazon-security.org',
    'apple-billing.com',
    'microsoft-support.net',
    'netfIix.com'
  ];

  const isSuspicious = suspiciousDomains.some(domain => email.toLowerCase().includes(domain.toLowerCase()));

  if (isSuspicious) {
    return (
      <span className="bg-red-100 text-red-800 px-1 rounded text-xs" title="Suspicious domain">
        {email}
      </span>
    );
  }

  return <span>{email}</span>;
};

export function EmailItem({ email, isSelected, onSelect }: EmailItemProps) {
  const hasThreats = email.riskLevel && email.riskLevel !== 'safe';

  return (
    <Card 
      className={`p-3 cursor-pointer transition-colors hover:bg-accent ${
        isSelected ? 'bg-accent border-primary' : ''
      } ${!email.isRead ? 'border-l-4 border-l-primary' : ''}`}
      onClick={onSelect}
    >
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className={`${!email.isRead ? 'font-medium' : ''}`}>
              {email.sender}
            </span>
            {email.isFlagged && (
              <div className="flex items-center gap-1">
                <Flag className={`h-3 w-3 ${getFlagColor(email.riskLevel)}`} />
                {getRiskBadge(email.riskLevel)}
              </div>
            )}
          </div>
          <span className="text-xs text-muted-foreground">
            {email.timestamp}
          </span>
        </div>
        
        {hasThreats && (
          <div className="text-xs text-muted-foreground">
            From: {highlightSenderEmail(email.senderEmail, email.riskLevel)}
          </div>
        )}
        
        <div className="space-y-1">
          <h4 className={`line-clamp-1 ${!email.isRead ? 'font-medium' : ''}`}>
            {email.subject}
          </h4>
          <div className="text-sm text-muted-foreground line-clamp-2">
            {hasThreats ? (
              <div 
                dangerouslySetInnerHTML={{ 
                  __html: highlightPreviewText(email.preview, email.riskLevel) 
                }} 
              />
            ) : (
              <p>{email.preview}</p>
            )}
          </div>
        </div>
      </div>
    </Card>
  );
}