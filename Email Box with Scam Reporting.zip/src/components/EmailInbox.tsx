import { useState } from 'react';
import { EmailList } from './EmailList';
import { EmailDetail } from './EmailDetail';
import { EmailScanner } from './EmailScanner';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Separator } from './ui/separator';
import { Shield, Settings } from 'lucide-react';

export type RiskLevel = 'safe' | 'suspicious' | 'high-risk' | 'scam';

export interface Email {
  id: string;
  sender: string;
  senderEmail: string;
  subject: string;
  preview: string;
  content: string;
  timestamp: string;
  isRead: boolean;
  isFlagged: boolean;
  isScam?: boolean;
  riskLevel?: RiskLevel;
}

const mockEmails: Email[] = [
  {
    id: '1',
    sender: 'Jennifer Martinez',
    senderEmail: 'jennifer.martinez@techcorp.com',
    subject: 'Q4 Budget Planning Meeting',
    preview: 'Hi team, I hope everyone is doing well. I wanted to schedule our quarterly budget planning session...',
    content: 'Hi team,\n\nI hope everyone is doing well. I wanted to schedule our quarterly budget planning session for next week. We need to review the current expenses and plan for Q4.\n\nProposed agenda:\n- Current budget review\n- Q4 projections\n- Department allocations\n- New project funding\n\nPlease let me know your availability for Tuesday or Wednesday afternoon.\n\nBest regards,\nJennifer Martinez\nFinance Manager',
    timestamp: '2 hours ago',
    isRead: false,
    isFlagged: false,
    riskLevel: 'safe'
  },
  {
    id: '2',
    sender: 'PayPal Security',
    senderEmail: 'security@secure-paypal.net',
    subject: 'Urgent: Verify Your Account Within 24 Hours',
    preview: 'We detected unusual activity on your PayPal account. Please verify your account immediately...',
    content: 'Dear PayPal Customer,\n\nWe have detected unusual activity on your PayPal account from an unrecognized device. For your security, we have temporarily limited your account access.\n\nTo restore full access, please verify your account within 24 hours by clicking the link below:\n\nVerify Account: http://secure-paypal.net/verify-account\n\nFailure to verify your account will result in permanent suspension.\n\nThank you for your immediate attention,\nPayPal Security Team\n\nThis is an automated message, please do not reply.',
    timestamp: '4 hours ago',
    isRead: true,
    isFlagged: true,
    isScam: true,
    riskLevel: 'scam'
  },
  {
    id: '3',
    sender: 'Alex Chen',
    senderEmail: 'alex.chen@designstudio.co',
    subject: 'Website Mockups Ready for Review',
    preview: 'Hey! The new website mockups are completed and ready for your feedback...',
    content: 'Hey!\n\nThe new website mockups are completed and ready for your feedback. I\'ve incorporated all the changes from our last meeting and added the new color scheme we discussed.\n\nYou can view them here: https://designstudio.co/client-portal/mockups\n\nKey updates:\n- Updated homepage layout\n- New navigation structure\n- Mobile responsive design\n- Improved accessibility features\n\nLet me know if you\'d like to schedule a call to go through them together.\n\nThanks,\nAlex Chen\nUX Designer',
    timestamp: '1 day ago',
    isRead: true,
    isFlagged: false,
    riskLevel: 'safe'
  },
  {
    id: '4',
    sender: 'Amazon Security',
    senderEmail: 'security@amazon-security.org',
    subject: 'Your Order Has Been Cancelled - Action Required',
    preview: 'Your recent order for $299.99 has been cancelled due to payment issues...',
    content: 'Dear Amazon Customer,\n\nYour recent order #AMZ-789456123 for $299.99 has been cancelled due to payment verification issues with your credit card.\n\nOrder Details:\n- Apple AirPods Pro (2nd Generation)\n- Quantity: 1\n- Total: $299.99\n\nTo reactivate your order and prevent future cancellations, please confirm your payment information immediately:\n\nConfirm Payment: http://amazon-security.org/payment-confirm\n\nYour order will be permanently cancelled if no action is taken within 24 hours.\n\nBest regards,\nAmazon Customer Service',
    timestamp: '1 day ago',
    isRead: false,
    isFlagged: true,
    isScam: true,
    riskLevel: 'scam'
  },
  {
    id: '5',
    sender: 'HR Department',
    senderEmail: 'hr@company.com',
    subject: 'Employee Benefits Enrollment Deadline',
    preview: 'Reminder: The deadline for employee benefits enrollment is approaching...',
    content: 'Dear Team,\n\nThis is a friendly reminder that the deadline for employee benefits enrollment is Friday, August 30th at 5:00 PM.\n\nIf you haven\'t already, please log into the benefits portal to:\n- Review your current coverage\n- Make changes to your health insurance\n- Update beneficiary information\n- Enroll in optional benefits (dental, vision, life insurance)\n\nThe portal can be accessed at: https://benefits.company.com\n\nIf you need assistance or have questions, please contact the HR department or attend one of our help sessions:\n- Tuesday, August 27th at 2:00 PM (Conference Room A)\n- Thursday, August 29th at 10:00 AM (Conference Room B)\n\nBest regards,\nHR Department',
    timestamp: '2 days ago',
    isRead: true,
    isFlagged: false,
    riskLevel: 'safe'
  },
  {
    id: '6',
    sender: 'Netflix Support',
    senderEmail: 'billing@netfIix.com',
    subject: 'Payment Failed - Update Required',
    preview: 'We were unable to process your Netflix payment. Please update your billing information...',
    content: 'Hello,\n\nWe were unable to process your payment for your Netflix subscription. Your account will be suspended if payment is not received within 48 hours.\n\nTo avoid service interruption, please update your payment information:\n\nUpdate Payment Method: bit.ly/netflix-billing-update\n\nYour current plan: Premium (4K Ultra HD)\nMonthly charge: $19.99\nNext billing date: August 25, 2025\n\nIf you believe this is an error, please contact our support team.\n\nThank you,\nNetflix Billing Support',
    timestamp: '3 hours ago',
    isRead: false,
    isFlagged: true,
    riskLevel: 'suspicious'
  },
  {
    id: '7',
    sender: 'Microsoft Security',
    senderEmail: 'security@microsoft-support.net',
    subject: 'Security Alert: Unusual Sign-in Activity',
    preview: 'We detected a sign-in attempt from an unusual location. Please secure your account...',
    content: 'Microsoft Security Alert\n\nWe detected an unusual sign-in attempt to your Microsoft account from:\n\nLocation: Unknown location\nDevice: Unknown device\nTime: August 23, 2025 at 3:42 AM\n\nIf this was you, you can safely ignore this message. If this wasn\'t you, your account may be compromised.\n\nSecure your account immediately:\n1. Change your password\n2. Enable two-factor authentication\n3. Review recent activity\n\nSecure Account Now: http://microsoft-support.net/security-check\n\nDon\'t delay - your account security depends on immediate action.\n\nMicrosoft Security Team',
    timestamp: '6 hours ago',
    isRead: true,
    isFlagged: true,
    riskLevel: 'high-risk'
  }
];

export function EmailInbox() {
  const [emails, setEmails] = useState<Email[]>(mockEmails);
  const [selectedEmail, setSelectedEmail] = useState<Email | null>(null);
  const [showScanner, setShowScanner] = useState(false);

  const handleEmailSelect = (email: Email) => {
    setSelectedEmail(email);
    // Mark as read when opened
    if (!email.isRead) {
      setEmails(prev => prev.map(e => 
        e.id === email.id ? { ...e, isRead: true } : e
      ));
    }
  };

  const handleFlagEmail = (emailId: string, riskLevel: RiskLevel = 'suspicious') => {
    setEmails(prev => prev.map(email => 
      email.id === emailId 
        ? { 
            ...email, 
            isFlagged: riskLevel !== 'safe', 
            isScam: riskLevel === 'scam',
            riskLevel 
          } 
        : email
    ));
  };

  const handleUnflagEmail = (emailId: string) => {
    setEmails(prev => prev.map(email => 
      email.id === emailId 
        ? { ...email, isFlagged: false, isScam: false, riskLevel: 'safe' } 
        : email
    ));
  };

  const handleScanComplete = (scannedEmails: Email[]) => {
    setEmails(scannedEmails);
  };

  const flaggedCount = emails.filter(e => e.isFlagged).length;
  const scamCount = emails.filter(e => e.riskLevel === 'scam').length;
  const suspiciousCount = emails.filter(e => e.riskLevel === 'suspicious').length;
  const highRiskCount = emails.filter(e => e.riskLevel === 'high-risk').length;

  return (
    <div className="h-screen flex">
      <Card className="w-1/3 m-4 mr-2">
        <div className="p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h1>Inbox</h1>
              <p className="text-muted-foreground">
                {emails.filter(e => !e.isRead).length} unread messages
              </p>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setShowScanner(true)}
              className="gap-2"
            >
              <Shield className="h-4 w-4" />
              Scan
            </Button>
          </div>
          
          {(flaggedCount > 0) && (
            <div className="space-y-2">
              {scamCount > 0 && (
                <div className="p-2 bg-red-50 border border-red-200 rounded-lg">
                  <div className="flex items-center gap-2 text-red-700 text-sm font-medium">
                    <Shield className="h-4 w-4" />
                    {scamCount} scam warning{scamCount !== 1 ? 's' : ''} detected
                  </div>
                </div>
              )}
              {highRiskCount > 0 && (
                <div className="p-2 bg-orange-50 border border-orange-200 rounded-lg">
                  <div className="flex items-center gap-2 text-orange-700 text-sm font-medium">
                    <Shield className="h-4 w-4" />
                    {highRiskCount} high-risk email{highRiskCount !== 1 ? 's' : ''}
                  </div>
                </div>
              )}
              {suspiciousCount > 0 && (
                <div className="p-2 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <div className="flex items-center gap-2 text-yellow-700 text-sm font-medium">
                    <Shield className="h-4 w-4" />
                    {suspiciousCount} suspicious email{suspiciousCount !== 1 ? 's' : ''}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
        <Separator />
        <EmailList 
          emails={emails}
          selectedEmail={selectedEmail}
          onEmailSelect={handleEmailSelect}
        />
      </Card>
      
      <Card className="flex-1 m-4 ml-2">
        {selectedEmail ? (
          <EmailDetail 
            email={selectedEmail}
            onFlag={handleFlagEmail}
            onUnflag={handleUnflagEmail}
          />
        ) : (
          <div className="flex items-center justify-center h-full text-muted-foreground">
            <div className="text-center space-y-2">
              <p>Select an email to read</p>
              <Button 
                variant="outline" 
                onClick={() => setShowScanner(true)}
                className="gap-2"
              >
                <Shield className="h-4 w-4" />
                Scan Emails for Threats
              </Button>
            </div>
          </div>
        )}
      </Card>

      <EmailScanner
        emails={emails}
        onScanComplete={handleScanComplete}
        isOpen={showScanner}
        onClose={() => setShowScanner(false)}
      />
    </div>
  );
}