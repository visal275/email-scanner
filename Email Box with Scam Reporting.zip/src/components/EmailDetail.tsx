import { useState } from 'react';
import { Email, RiskLevel } from './EmailInbox';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { ScrollArea } from './ui/scroll-area';
import { 
  Flag, 
  AlertTriangle, 
  MoreVertical, 
  Reply, 
  ReplyAll, 
  Forward,
  Shield,
  Eye,
  EyeOff
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { FlagDialog } from './FlagDialog';

interface EmailDetailProps {
  email: Email;
  onFlag: (emailId: string, riskLevel?: RiskLevel) => void;
  onUnflag: (emailId: string) => void;
}

interface HighlightRule {
  patterns: string[];
  className: string;
  label: string;
  priority: number;
}

const highlightRules: HighlightRule[] = [
  {
    patterns: [
      'secure-paypal.net',
      'amazon-security.org',
      'apple-billing.com',
      'microsoft-support.net',
      'netfIix.com',
      'payp4l',
      'amaz0n',
      'g00gle'
    ],
    className: 'bg-red-100 text-red-800 px-1 rounded font-medium',
    label: 'Fake Domain',
    priority: 1
  },
  {
    patterns: [
      'http://secure-paypal.net',
      'http://amazon-security.org',
      'http://microsoft-support.net',
      'bit.ly/',
      'tinyurl.com/'
    ],
    className: 'bg-red-100 text-red-800 px-1 rounded underline',
    label: 'Malicious Link',
    priority: 2
  },
  {
    patterns: [
      'verify your account within 24 hours',
      'your account will be suspended',
      'confirm your identity immediately',
      'action required',
      'urgent',
      'immediately',
      'within 24 hours',
      'limited time',
      'expires today'
    ],
    className: 'bg-orange-100 text-orange-800 px-1 rounded',
    label: 'Urgency Pressure',
    priority: 3
  },
  {
    patterns: [
      'payment failed',
      'payment issues',
      'billing problem',
      'card declined',
      'update payment',
      'payment verification',
      'billing information'
    ],
    className: 'bg-yellow-100 text-yellow-800 px-1 rounded',
    label: 'Payment Pressure',
    priority: 4
  },
  {
    patterns: [
      'account suspended',
      'account limited',
      'security alert',
      'unusual activity',
      'unauthorized access',
      'verify account',
      'confirm identity'
    ],
    className: 'bg-purple-100 text-purple-800 px-1 rounded',
    label: 'Account Threat',
    priority: 5
  }
];

const highlightSuspiciousContent = (content: string): string => {
  let highlightedContent = content;
  
  // Sort rules by priority to ensure higher priority highlights take precedence
  const sortedRules = [...highlightRules].sort((a, b) => a.priority - b.priority);
  
  sortedRules.forEach(rule => {
    rule.patterns.forEach(pattern => {
      const regex = new RegExp(`(${pattern.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
      highlightedContent = highlightedContent.replace(
        regex, 
        `<span class="${rule.className}" title="${rule.label}">$1</span>`
      );
    });
  });
  
  return highlightedContent;
};

const highlightSuspiciousEmail = (email: string): JSX.Element => {
  const suspiciousDomains = [
    'secure-paypal.net',
    'amazon-security.org',
    'apple-billing.com',
    'microsoft-support.net',
    'netfIix.com',
    'payp4l',
    'amaz0n',
    'g00gle'
  ];

  const isSuspicious = suspiciousDomains.some(domain => email.toLowerCase().includes(domain.toLowerCase()));

  if (isSuspicious) {
    return (
      <span className="bg-red-100 text-red-800 px-1 rounded font-medium" title="Suspicious sender domain">
        {email}
      </span>
    );
  }

  return <span>{email}</span>;
};

const getRiskBadge = (riskLevel?: RiskLevel) => {
  switch (riskLevel) {
    case 'scam':
      return (
        <Badge variant="destructive">
          <AlertTriangle className="h-3 w-3 mr-1" />
          Scam Warning
        </Badge>
      );
    case 'high-risk':
      return (
        <Badge className="bg-orange-100 text-orange-800 hover:bg-orange-200">
          <Shield className="h-3 w-3 mr-1" />
          High Risk
        </Badge>
      );
    case 'suspicious':
      return (
        <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-200">
          <Flag className="h-3 w-3 mr-1" />
          Suspicious
        </Badge>
      );
    default:
      return null;
  }
};

const getFlagColor = (riskLevel?: RiskLevel) => {
  switch (riskLevel) {
    case 'scam':
      return 'text-red-500';
    case 'high-risk':
      return 'text-orange-500';
    case 'suspicious':
      return 'text-yellow-500';
    default:
      return 'text-orange-500';
  }
};

export function EmailDetail({ email, onFlag, onUnflag }: EmailDetailProps) {
  const [showFlagDialog, setShowFlagDialog] = useState(false);
  const [showHighlights, setShowHighlights] = useState(true);

  const hasThreats = email.riskLevel && email.riskLevel !== 'safe';

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="p-6 border-b">
        <div className="flex items-start justify-between mb-4">
          <div className="space-y-1 flex-1">
            <div className="flex items-center gap-2">
              <h2>{email.subject}</h2>
              {email.isFlagged && (
                <div className="flex items-center gap-2">
                  <Flag className={`h-4 w-4 ${getFlagColor(email.riskLevel)}`} />
                  {getRiskBadge(email.riskLevel)}
                </div>
              )}
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span>
                From: {email.sender} &lt;
                {hasThreats && showHighlights ? 
                  highlightSuspiciousEmail(email.senderEmail) : 
                  email.senderEmail
                }
                &gt;
              </span>
              <span>•</span>
              <span>{email.timestamp}</span>
            </div>
          </div>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setShowFlagDialog(true)}>
                <Flag className="h-4 w-4 mr-2" />
                {email.isFlagged ? 'Update Flag' : 'Flag Email'}
              </DropdownMenuItem>
              {email.isFlagged && (
                <DropdownMenuItem onClick={() => onUnflag(email.id)}>
                  Remove Flag
                </DropdownMenuItem>
              )}
              {hasThreats && (
                <DropdownMenuItem onClick={() => setShowHighlights(!showHighlights)}>
                  {showHighlights ? (
                    <>
                      <EyeOff className="h-4 w-4 mr-2" />
                      Hide Highlights
                    </>
                  ) : (
                    <>
                      <Eye className="h-4 w-4 mr-2" />
                      Show Highlights
                    </>
                  )}
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
        
        {/* Threat Legend */}
        {hasThreats && showHighlights && (
          <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Shield className="h-4 w-4 text-amber-600" />
              <span className="text-sm font-medium text-amber-800">Threat Indicators Detected</span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-xs">
              <div className="flex items-center gap-1">
                <span className="bg-red-100 text-red-800 px-1 rounded">●</span>
                <span>Fake Domain</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="bg-orange-100 text-orange-800 px-1 rounded">●</span>
                <span>Urgency Pressure</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="bg-yellow-100 text-yellow-800 px-1 rounded">●</span>
                <span>Payment Pressure</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="bg-purple-100 text-purple-800 px-1 rounded">●</span>
                <span>Account Threat</span>
              </div>
            </div>
          </div>
        )}
        
        {/* Action Buttons */}
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Reply className="h-4 w-4 mr-2" />
            Reply
          </Button>
          <Button variant="outline" size="sm">
            <ReplyAll className="h-4 w-4 mr-2" />
            Reply All
          </Button>
          <Button variant="outline" size="sm">
            <Forward className="h-4 w-4 mr-2" />
            Forward
          </Button>
          {hasThreats && (
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => setShowHighlights(!showHighlights)}
            >
              {showHighlights ? (
                <>
                  <EyeOff className="h-4 w-4 mr-2" />
                  Hide Highlights
                </>
              ) : (
                <>
                  <Eye className="h-4 w-4 mr-2" />
                  Show Highlights
                </>
              )}
            </Button>
          )}
        </div>
      </div>

      {/* Content */}
      <ScrollArea className="flex-1 p-6">
        <div className="whitespace-pre-wrap">
          {hasThreats && showHighlights ? (
            <div 
              dangerouslySetInnerHTML={{ 
                __html: highlightSuspiciousContent(email.content) 
              }} 
            />
          ) : (
            email.content
          )}
        </div>
      </ScrollArea>

      <FlagDialog
        isOpen={showFlagDialog}
        onClose={() => setShowFlagDialog(false)}
        onFlag={(riskLevel) => onFlag(email.id, riskLevel)}
        currentRiskLevel={email.riskLevel}
      />
    </div>
  );
}