import { Email } from './EmailInbox';
import { EmailItem } from './EmailItem';
import { ScrollArea } from './ui/scroll-area';

interface EmailListProps {
  emails: Email[];
  selectedEmail: Email | null;
  onEmailSelect: (email: Email) => void;
}

export function EmailList({ emails, selectedEmail, onEmailSelect }: EmailListProps) {
  return (
    <ScrollArea className="h-[calc(100vh-120px)]">
      <div className="space-y-1 p-2">
        {emails.map(email => (
          <EmailItem
            key={email.id}
            email={email}
            isSelected={selectedEmail?.id === email.id}
            onSelect={() => onEmailSelect(email)}
          />
        ))}
      </div>
    </ScrollArea>
  );
}