import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { Button } from './ui/button';
import { RadioGroup, RadioGroupItem } from './ui/radio-group';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { AlertTriangle, Flag, Mail, Shield } from 'lucide-react';
import { RiskLevel } from './EmailInbox';

interface FlagDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onFlag: (riskLevel: RiskLevel) => void;
  currentRiskLevel?: RiskLevel;
}

export function FlagDialog({ 
  isOpen, 
  onClose, 
  onFlag, 
  currentRiskLevel 
}: FlagDialogProps) {
  const [flagType, setFlagType] = useState<RiskLevel>(
    currentRiskLevel || 'suspicious'
  );
  const [reason, setReason] = useState('');

  const handleSubmit = () => {
    onFlag(flagType);
    onClose();
    setReason('');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Flag className="h-5 w-5" />
            Flag Email
          </DialogTitle>
          <DialogDescription>
            Help protect others by reporting suspicious or dangerous emails.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <RadioGroup value={flagType} onValueChange={(value) => setFlagType(value as RiskLevel)}>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="suspicious" id="suspicious" />
              <Label htmlFor="suspicious" className="flex items-center gap-2">
                <Flag className="h-4 w-4 text-yellow-500" />
                <span>Suspicious - Potentially misleading</span>
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="high-risk" id="high-risk" />
              <Label htmlFor="high-risk" className="flex items-center gap-2">
                <Shield className="h-4 w-4 text-orange-500" />
                <span>High Risk - Likely phishing attempt</span>
              </Label>
            </div>
            <div className="flex items-center space-x-2">
              <RadioGroupItem value="scam" id="scam" />
              <Label htmlFor="scam" className="flex items-center gap-2">
                <AlertTriangle className="h-4 w-4 text-red-500" />
                <span>Scam Warning - Confirmed fraud attempt</span>
              </Label>
            </div>
          </RadioGroup>

          <div className="space-y-2">
            <Label htmlFor="reason">Additional details (optional)</Label>
            <Textarea
              id="reason"
              placeholder="Describe why you're flagging this email..."
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              rows={3}
            />
          </div>

          {flagType === 'suspicious' && (
            <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
              <p className="text-sm text-yellow-800">
                <strong>Suspicious emails</strong> contain elements that seem questionable but may not be outright scams. This helps other users be cautious.
              </p>
            </div>
          )}

          {flagType === 'high-risk' && (
            <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
              <p className="text-sm text-orange-800">
                <strong>High-risk emails</strong> likely contain phishing attempts or other serious threats that could compromise security.
              </p>
            </div>
          )}

          {flagType === 'scam' && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm text-red-800">
                <strong>Scam Warning emails</strong> are confirmed fraudulent attempts to steal information, money, or compromise accounts.
              </p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit}>
            Flag Email
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}